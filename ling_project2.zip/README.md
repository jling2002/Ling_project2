# project 2: words in motion
by Jing Ling

# project overview
I made a webpage consisting of two interactive elements: text and color. Using these two components, I aimed to illustrate what community means to me. When I think of community, I think about the people I have relied on and helped. Life is filled with ups and downs so it is important to have good quality relationships.

I chose the song 'Be Alright' by Ariana Grande because it includes themes of support and resilience which are crucial aspects of a community. The lyrics offers comfort and hope during difficult times, assuring that you are not alone and things will eventually get better. Grande encourages you to rely on one another by creating a sense of unity and belonging which is what I think community is about. 

The imagery I wanted to create from the lyrics represent going through the rain to get to the sunlight. Good days would not exist if bad days never happens. There is always light at the end of the tunnel so never give up hope. 

# technical overview
WORKING IN PROGRESS

This project consists of ten HTML pages and their own CSS pages. 

The second HTML page has a animation that creates a falling effect of the words to represent the motion of rain. 

# acknowledgment 

Song lyrics for 'Be Alright' by Ariana Grande

